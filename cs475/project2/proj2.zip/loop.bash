g++ proj2.cpp -o proj2 -lm -fopenmp
./proj2