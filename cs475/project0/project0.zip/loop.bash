for t in 1 4
do 
    echo NUMT = $t
    g++ -DNUMT=$t project0.cpp -o proj0 -lm -fopenmp
    ./proj0
done