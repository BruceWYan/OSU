Hi there! Welcome to my project0 submission. 
Included in this zip file is copy of my project0.c code and a bash scrip which will parallelize the code. 

If you intend on running the code, make sure you are in the right directory and run 'bash loop.bash' in the terminal. 

Thanks!